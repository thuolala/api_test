package demo.test;

import demo.entity.Category;
import demo.entity.enums.CategoryType;
import demo.helper.SuperCSVHelper;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.testng.annotations.AfterClass;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SuperCSVTest_JUnit5 {

    private static final String[] HEADERS = {"categoryID", "categoryName", "type", "allocatedAmount"};

    // Input
    private static final String TEST_CSV_CATEGORY_PATH_IN = "./src/test/java/demo/csv/category_input.csv";
    private static final String TEST_CSV_BUDGET_PATH_IN = "./src/test/java/demo/csv/budget_input.csv";

    // Output
    private static final String TEST_CSV_CATEGORY_PATH_OUT = "./src/test/java/demo/csv/category_output.csv";
    private static final String TEST_CSV_BUDGET_PATH_OUT = "./src/test/java/demo/csv/budget_output.csv";

    private static List<Category> categoryList;

    @BeforeAll
    @DisplayName("Add more Category")
    static void start() {
        System.out.println("@BeforeAll - START\n");

        categoryList = new ArrayList<>(Arrays.asList(
                new Category("CA0005", "Gaming", CategoryType.SAVING, 3000000),
                new Category("CA0006", "Health", CategoryType.SAVING, 5000000)
        ));
    }

    @BeforeEach
    @DisplayName("Run before each test")
    void printBeforeEachTest(){
        categoryList = new ArrayList<>(Arrays.asList(
                new Category("CA0005", "Gaming", CategoryType.SAVING, 3000000),
                new Category("CA0006", "Health", CategoryType.SAVING, 5000000)
        ));

        System.out.println("----------------------START TEST----------------------");
    }

    @Tag("Read")
    @Test
    @DisplayName("Should read CSV successfully")
    void testReadCSV() {
        System.out.println("@Test - Read then print");

        List<Category> result = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_IN, Category.class, HEADERS);

        assertEquals(4, result.size());
        assertEquals("Salary", result.get(0).getCategoryName());
        assertEquals(CategoryType.INCOME, result.get(0).getType());
        assertEquals(1000000, result.get(0).getAllocatedAmount());

        System.out.println("Result after read:");
        result.forEach(System.out::println);
    }

    @Tag("Write")
    @Test
    @DisplayName("Should write CSV successfully")
    void testWriteCSV() {
        System.out.println("@Test - Write then print");

        SuperCSVHelper.writeCSV(TEST_CSV_CATEGORY_PATH_OUT, categoryList, HEADERS, Category.class);
        File file = new File(TEST_CSV_CATEGORY_PATH_OUT);
        assertTrue(file.exists());
        assertTrue(file.length() > 0);

        List<Category> result = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_OUT, Category.class, HEADERS);
        System.out.println("Result after write:");
        result.forEach(System.out::println);

    }

    @Tag("Read")
    @Test
    @DisplayName("Append from read to write")
    void testAppendCSV() {
        System.out.println("@Test - Append then print");

        List<Category> inputList = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_IN, Category.class, HEADERS);

        List<Category> combinedList = new ArrayList<>(inputList);
        combinedList.addAll(categoryList);

        SuperCSVHelper.writeCSV(TEST_CSV_CATEGORY_PATH_OUT, combinedList, HEADERS, Category.class);

        File file = new File(TEST_CSV_CATEGORY_PATH_OUT);
        assertTrue(file.exists());
        assertTrue(file.length() > 0);

        List<Category> result = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_OUT, Category.class, HEADERS);
        System.out.println("Result after append:");
        result.forEach(System.out::println);
    }

    @ParameterizedTest(name = "[{index}] ID={0}, Name={1}")
    @CsvSource({
            "CA0007, Travel, EXPENSE, 2000000",
            "CA0008, Study, SAVING, 1500000"
    })
    @DisplayName("Test category creation with different inputs")
    void testCategoryWithParams(String id, String name, String typeStr, long amount) {
        System.out.println("@ParameterizedTest - Create then print");

        CategoryType type = CategoryType.valueOf(typeStr);
        Category c = new Category(id, name, type, amount);
        categoryList.add(c);

        assertNotNull(c);
        assertEquals(name, c.getCategoryName());

        categoryList.forEach(System.out::println);
    }

    @Tag("Read")
    @RepeatedTest(3)
    @DisplayName("Repeat read CSV test")
    void repeatedReadCSVTest() {
        System.out.println("@RepeatedTest - Read then print");

        List<Category> result = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_IN, Category.class, HEADERS);
        assertTrue(result.size() > 0);

        System.out.println("Result after read:");
        result.forEach(System.out::println);
    }

    @TestFactory
    Collection<DynamicTest> dynamicTestsFromCategoryList() {
        System.out.println("@TestFactory - Dynamic Test");

        List<Category> categories = categoryList;

        List<DynamicTest> tests = categories.stream()
                .map(cat -> DynamicTest.dynamicTest("Test category " + cat.getCategoryName(),
                        () -> assertNotNull(cat.getCategoryID())))
                .toList();

        System.out.println("Generated Dynamic Tests:");
        tests.forEach(System.out::println);

        return tests;
    }

    @Nested
    @DisplayName("Group: CSV Reading Tests")
    class CSVReadingTests {
        @Test
        void readCSVNotEmpty() {
            System.out.println("@Nested - Read then print");

            List<Category> result = SuperCSVHelper.readCSV(TEST_CSV_CATEGORY_PATH_IN, Category.class, HEADERS);
            assertFalse(result.isEmpty());

            System.out.println("Result after read:");
            result.forEach(System.out::println);
        }
    }

    @Disabled("This feature not ready yet")
    @Test
    void testFutureFeature() {
        fail("Should not run");
    }

    @AfterEach
    void printAfterEachTest() {
        System.out.println("-----------------------END TEST-----------------------");
    }

    @AfterAll
    static void end(){
        System.out.println("@BeforeAll - END\n");
    }
}
