package demo.entity.enums;

public enum CategoryType {
    INCOME,
    EXPENSE,
    SAVING
}
