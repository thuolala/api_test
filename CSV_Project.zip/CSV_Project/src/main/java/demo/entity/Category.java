package demo.entity;

import demo.entity.enums.CategoryType;

import java.util.Objects;

public class Category {
    private String categoryID;
    private String categoryName;
    private CategoryType type = CategoryType.INCOME; // default
    private long allocatedAmount;

    public Category() {
    }

    public Category(String categoryID, String categoryName, CategoryType type, long allocatedAmount) {
        this.categoryID = categoryID;
        this.categoryName = categoryName;
        this.type = type;
        this.allocatedAmount = allocatedAmount;
    }

    public String getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(String categoryID) {
        this.categoryID = categoryID;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public CategoryType getType() {
        return type;
    }

    public void setType(CategoryType type) {
        this.type = type;
    }

    public long getAllocatedAmount() {
        return allocatedAmount;
    }

    public void setAllocatedAmount(long allocatedAmount) {
        this.allocatedAmount = allocatedAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Category category = (Category) o;
        return allocatedAmount == category.allocatedAmount && Objects.equals(categoryID, category.categoryID) && Objects.equals(categoryName, category.categoryName) && type == category.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(categoryID, categoryName, type, allocatedAmount);
    }

    @Override
    public String toString() {
        return "Category{" +
                "categoryID='" + categoryID + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", type=" + type +
                ", allocatedAmount=" + allocatedAmount +
                '}';
    }
}