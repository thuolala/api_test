package demo.entity;

import demo.entity.enums.CategoryType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Budget {
    private String budgetID;
    private long totalAmount;
    private int month;
    private int year;
    private ArrayList<Category> categories = new ArrayList<>();
    private long allocatedAmount;
}
