package demo.helper;

import demo.entity.enums.CategoryType;
import org.supercsv.cellprocessor.ParseEnum;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SuperCSVHelper {
    private static CellProcessor[] processors = new CellProcessor[] {
            new NotNull(),                        // categoryID
            new NotNull(),                        // categoryName
            new ParseEnum(CategoryType.class),  // enum type
            new ParseLong()                       // allocatedAmount
    };

    // Reads CSV into a list of objects
    public static <T> List<T> readCSV(String filePath, Class<T> clazz, String[] fields) {
        List<T> result = new ArrayList<>();

        try (Reader reader = new FileReader(filePath);
             ICsvBeanReader beanReader = new CsvBeanReader(reader, CsvPreference.STANDARD_PREFERENCE)) {

            beanReader.getHeader(true); // skip header if exists

            T bean;
            while ((bean = beanReader.read(clazz, fields, processors)) != null) {
                result.add(bean);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }

    // Writes list of objects into CSV
    public static <T> void writeCSV(String filePath, List<T> data, String[] fields, Class<T> clazz) {
        try (Writer writer = new FileWriter(filePath);
             ICsvBeanWriter beanWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE)) {

            beanWriter.writeHeader(fields);

            for (T item : data) {
                beanWriter.write(item, fields);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
