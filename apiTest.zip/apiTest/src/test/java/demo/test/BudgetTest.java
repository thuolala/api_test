package demo.test;

public class BudgetTest {
}
