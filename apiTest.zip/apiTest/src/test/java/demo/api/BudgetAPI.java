package demo.api;

public class BudgetAPI {
}
